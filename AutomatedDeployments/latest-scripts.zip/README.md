azure-sdk-tools-samples
=======================

Samples for Windows Azure PowerShell

## Current Samples

### Automated Deployment using Remote PowerShell (WinRM)

* Active Directory
* SQL Server 2013 
* SharePoint Server 2013 


[See our Wiki to Get Started] (https://github.com/WindowsAzure/azure-sdk-tools-samples/wiki)